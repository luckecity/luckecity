﻿Imports MySql.Data.MySqlClient

Public Class frmProfile
    Private Sub Guna2GradientPanel1_Paint(sender As Object, e As PaintEventArgs) Handles Guna2GradientPanel1.Paint

    End Sub


    Private Sub frmProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'connecting to the database
            Dim con As New dbConnection
            con.connection.Open()
            con.query = "SELECT Courses FROM collegecourse"
            con.cm = New MySqlCommand(con.query, con.connection)
            con.dr = con.cm.ExecuteReader

            'looping all the course in the database
            While con.dr.Read = True
                cmbCourse.Items.Add(con.dr("Courses"))
            End While

            'closing the connection
            con.connection.Close()
            con.cm.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Guna2GradientButton3_Click(sender As Object, e As EventArgs) Handles Guna2GradientButton3.Click
        frmPayment.Show() 'display the form to update payment

    End Sub

    Private Sub Guna2GradientButton1_Click(sender As Object, e As EventArgs) Handles Guna2GradientButton1.Click
        Try
            'instance of the class
            Dim NewStudent As New dbConnection

            'inserting the values of the new student
            NewStudent.MakePayment(Trim(txtID.Text), txtFn.Text, txtLn.Text, cmbGender.Text, cmbCourse.Text)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Guna2GradientButton4_Click(sender As Object, e As EventArgs) Handles Guna2GradientButton4.Click
        frmViewBalance.Show()
    End Sub
End Class
