﻿Imports MySql.Data.MySqlClient
Public Class frmPayment
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        If txtID.Text = String.Empty Then
            MsgBox("Please enter the ID")

        Else
            Try
                'connect to db
                Dim con As New dbConnection
                con.connection.Open()
                con.query = "SELECT FirstName, CourseName, LastName from student WHERE ID='" & Trim(txtID.Text) & "'"
                con.cm = New MySqlCommand(con.query, con.connection)
                con.dr = con.cm.ExecuteReader

                'check if item is found and fill the details
                If con.dr.Read = True Then
                    txtFullName.Text = con.dr("LastName") & " " & con.dr("FirstName")
                    txtCourse.Text = con.dr("CourseName")

                    btnPayment.Visible = True 'display the button to make payment

                    'display a message if ID is not found
                Else
                    MsgBox("Student with this ID '" & txtID.Text & "' does not exist")
                End If

                con.connection.Close()
                con.cm.Dispose()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        Try
            If txtPaidTo.Text = String.Empty Then
                ErrorProvider1.SetError(txtPaidTo, "Mandatory")

            ElseIf txtReciept.Text = String.Empty Then
                ErrorProvider1.SetError(txtReciept, "Mandatory")

            ElseIf txtAmountPaid.Text = String.Empty Then
                ErrorProvider1.SetError(txtAmountPaid, "Mandatory")
            Else
                'instance of the class dbconnection
                Dim Payment As New dbConnection
                Payment.MakePayment(txtID.Text, txtAmountPaid.Text, txtPaidTo.Text, dtDate.Text, txtReciept.Text, txtCourse.Text)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtPaidTo_TextChanged(sender As Object, e As EventArgs) Handles txtPaidTo.TextChanged
        ErrorProvider1.Clear() 'clear the error provider

    End Sub

    Private Sub txtReciept_TextChanged(sender As Object, e As EventArgs) Handles txtReciept.TextChanged
        ErrorProvider1.Clear() 'clear the error provider
    End Sub

    Private Sub txtAmountPaid_TextChanged(sender As Object, e As EventArgs) Handles txtAmountPaid.TextChanged
        ErrorProvider1.Clear() 'clear the error provider
    End Sub
End Class