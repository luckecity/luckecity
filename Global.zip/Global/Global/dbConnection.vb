﻿Imports MySql.Data.MySqlClient
Public Class dbConnection

    Public query As String
    Public cm As New MySqlCommand
    Public dr As MySqlDataReader
    Public connection As New MySqlConnection("server=localhost;user id=root;password=lucky;database=studentbalance")

    'inserting a new instalment
    Public Sub MakePayment(ByVal ID, PaidAmount, PaidTo, PaidOn, Reciept, Course)
        Try
            connection.Open()
            'query = "UPDATE studentcourse SET Amount=Amount-'" & Amount & "' WHERE ID='" & ID & "'"
            query = "INSERT INTO studentcourse(ID, PaidAmount, PaidTo, PaidOn, ReceiptNo, CourseName) VALUES(@ID, @PaidAmount, @PaidTo, @PaidOn, @ReceiptNo, @CourseName)"
            cm = New MySqlCommand(query, connection)

            'passing the values
            cm.Parameters.AddWithValue("@ID", ID)
            cm.Parameters.AddWithValue("@PaidAmount", PaidAmount)
            cm.Parameters.AddWithValue("@PaidTo", PaidTo)
            cm.Parameters.AddWithValue("@PaidOn", PaidOn)
            cm.Parameters.AddWithValue("@ReceiptNo", Reciept)
            cm.Parameters.AddWithValue("@CourseName", Course)

            'execute the command
            cm.ExecuteNonQuery()

            'notify the user
            MessageBox.Show("Payment made successfully")

            'close the connection
            connection.Close()
            cm.Dispose()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    'inserting a new student
    Public Sub MakePayment(ByVal ID, Fn, Ln, Gender, Course)
        Try
            connection.Open()
            'query = "UPDATE studentcourse SET Amount=Amount-'" & Amount & "' WHERE ID='" & ID & "'"
            query = "INSERT INTO student(ID, FirstName, LastName, Gender, CourseName) VALUES(@ID, @FirstName, @LastName, @Gender, @CourseName)"
            cm = New MySqlCommand(query, connection)

            'passing the values
            cm.Parameters.AddWithValue("@ID", ID)
            cm.Parameters.AddWithValue("@FirstName", Fn)
            cm.Parameters.AddWithValue("@LastName", Ln)
            cm.Parameters.AddWithValue("@Gender", Gender)
            cm.Parameters.AddWithValue("@CourseName", Course)

            'execute the command
            cm.ExecuteNonQuery()

            'notify the user
            MessageBox.Show("Student successfully registered")

            'close the connection
            connection.Close()
            cm.Dispose()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

End Class
