﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayment
    Inherits MetroFramework.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.txtAmountPaid = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.btnPayment = New Guna.UI2.WinForms.Guna2Button()
        Me.dtDate = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.txtPaidTo = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.btnSearch = New Guna.UI2.WinForms.Guna2Button()
        Me.txtID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtReciept = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtCourse = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtFullName = New Guna.UI2.WinForms.Guna2TextBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Guna2CustomGradientPanel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2CustomGradientPanel1
        '
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtAmountPaid)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.btnPayment)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.dtDate)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtPaidTo)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.btnSearch)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtID)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtReciept)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtCourse)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.txtFullName)
        Me.Guna2CustomGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2CustomGradientPanel1.FillColor = System.Drawing.Color.Black
        Me.Guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2CustomGradientPanel1.FillColor4 = System.Drawing.Color.Transparent
        Me.Guna2CustomGradientPanel1.Location = New System.Drawing.Point(20, 60)
        Me.Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Me.Guna2CustomGradientPanel1.ShadowDecoration.Parent = Me.Guna2CustomGradientPanel1
        Me.Guna2CustomGradientPanel1.Size = New System.Drawing.Size(634, 425)
        Me.Guna2CustomGradientPanel1.TabIndex = 0
        '
        'txtAmountPaid
        '
        Me.txtAmountPaid.AutoRoundedCorners = True
        Me.txtAmountPaid.BackColor = System.Drawing.Color.Transparent
        Me.txtAmountPaid.BorderRadius = 18
        Me.txtAmountPaid.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAmountPaid.DefaultText = ""
        Me.txtAmountPaid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtAmountPaid.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtAmountPaid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAmountPaid.DisabledState.Parent = Me.txtAmountPaid
        Me.txtAmountPaid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtAmountPaid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAmountPaid.FocusedState.Parent = Me.txtAmountPaid
        Me.txtAmountPaid.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.txtAmountPaid.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAmountPaid.HoverState.Parent = Me.txtAmountPaid
        Me.txtAmountPaid.Location = New System.Drawing.Point(153, 236)
        Me.txtAmountPaid.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtAmountPaid.Name = "txtAmountPaid"
        Me.txtAmountPaid.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAmountPaid.PlaceholderText = ""
        Me.txtAmountPaid.SelectedText = ""
        Me.txtAmountPaid.ShadowDecoration.Parent = Me.txtAmountPaid
        Me.txtAmountPaid.Size = New System.Drawing.Size(124, 39)
        Me.txtAmountPaid.TabIndex = 17
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(51, 253)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(94, 22)
        Me.Guna2HtmlLabel6.TabIndex = 16
        Me.Guna2HtmlLabel6.Text = "Amount Paid"
        '
        'btnPayment
        '
        Me.btnPayment.AutoRoundedCorners = True
        Me.btnPayment.BackColor = System.Drawing.Color.Transparent
        Me.btnPayment.BorderRadius = 17
        Me.btnPayment.CheckedState.Parent = Me.btnPayment
        Me.btnPayment.CustomImages.Parent = Me.btnPayment
        Me.btnPayment.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.btnPayment.ForeColor = System.Drawing.Color.White
        Me.btnPayment.HoverState.Parent = Me.btnPayment
        Me.btnPayment.Location = New System.Drawing.Point(438, 386)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.ShadowDecoration.Parent = Me.btnPayment
        Me.btnPayment.Size = New System.Drawing.Size(191, 36)
        Me.btnPayment.TabIndex = 15
        Me.btnPayment.Text = "Update Payment"
        Me.btnPayment.UseTransparentBackground = True
        Me.btnPayment.Visible = False
        '
        'dtDate
        '
        Me.dtDate.AutoRoundedCorners = True
        Me.dtDate.BackColor = System.Drawing.Color.Transparent
        Me.dtDate.BorderRadius = 17
        Me.dtDate.CheckedState.Parent = Me.dtDate
        Me.dtDate.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.dtDate.HoverState.Parent = Me.dtDate
        Me.dtDate.Location = New System.Drawing.Point(374, 303)
        Me.dtDate.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.dtDate.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.dtDate.Name = "dtDate"
        Me.dtDate.ShadowDecoration.Parent = Me.dtDate
        Me.dtDate.Size = New System.Drawing.Size(255, 36)
        Me.dtDate.TabIndex = 14
        Me.dtDate.UseTransparentBackground = True
        Me.dtDate.Value = New Date(2021, 5, 23, 8, 33, 2, 479)
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(312, 317)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(56, 22)
        Me.Guna2HtmlLabel5.TabIndex = 13
        Me.Guna2HtmlLabel5.Text = "Paid on"
        '
        'txtPaidTo
        '
        Me.txtPaidTo.AutoRoundedCorners = True
        Me.txtPaidTo.BackColor = System.Drawing.Color.Transparent
        Me.txtPaidTo.BorderRadius = 18
        Me.txtPaidTo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPaidTo.DefaultText = ""
        Me.txtPaidTo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtPaidTo.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtPaidTo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPaidTo.DisabledState.Parent = Me.txtPaidTo
        Me.txtPaidTo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPaidTo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPaidTo.FocusedState.Parent = Me.txtPaidTo
        Me.txtPaidTo.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.txtPaidTo.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPaidTo.HoverState.Parent = Me.txtPaidTo
        Me.txtPaidTo.Location = New System.Drawing.Point(349, 236)
        Me.txtPaidTo.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtPaidTo.Name = "txtPaidTo"
        Me.txtPaidTo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPaidTo.PlaceholderText = ""
        Me.txtPaidTo.SelectedText = ""
        Me.txtPaidTo.ShadowDecoration.Parent = Me.txtPaidTo
        Me.txtPaidTo.Size = New System.Drawing.Size(214, 39)
        Me.txtPaidTo.TabIndex = 12
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(285, 253)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(56, 22)
        Me.Guna2HtmlLabel4.TabIndex = 11
        Me.Guna2HtmlLabel4.Text = "Paid To"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(53, 317)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(94, 22)
        Me.Guna2HtmlLabel3.TabIndex = 10
        Me.Guna2HtmlLabel3.Text = "Receipt NO#"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(34, 184)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(120, 22)
        Me.Guna2HtmlLabel2.TabIndex = 9
        Me.Guna2HtmlLabel2.Text = "Course Studying"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(80, 126)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(74, 22)
        Me.Guna2HtmlLabel1.TabIndex = 8
        Me.Guna2HtmlLabel1.Text = "Full Name"
        '
        'btnSearch
        '
        Me.btnSearch.AutoRoundedCorners = True
        Me.btnSearch.BackColor = System.Drawing.Color.Transparent
        Me.btnSearch.BorderRadius = 17
        Me.btnSearch.CheckedState.Parent = Me.btnSearch
        Me.btnSearch.CustomImages.Parent = Me.btnSearch
        Me.btnSearch.Font = New System.Drawing.Font("Century Schoolbook", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.White
        Me.btnSearch.HoverState.Parent = Me.btnSearch
        Me.btnSearch.Location = New System.Drawing.Point(499, 25)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.ShadowDecoration.Parent = Me.btnSearch
        Me.btnSearch.Size = New System.Drawing.Size(101, 36)
        Me.btnSearch.TabIndex = 7
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseTransparentBackground = True
        '
        'txtID
        '
        Me.txtID.AutoRoundedCorners = True
        Me.txtID.BackColor = System.Drawing.Color.Transparent
        Me.txtID.BorderRadius = 16
        Me.txtID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtID.DefaultText = ""
        Me.txtID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtID.DisabledState.Parent = Me.txtID
        Me.txtID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtID.FocusedState.Parent = Me.txtID
        Me.txtID.Font = New System.Drawing.Font("Century Schoolbook", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtID.HoverState.Parent = Me.txtID
        Me.txtID.Location = New System.Drawing.Point(133, 25)
        Me.txtID.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtID.Name = "txtID"
        Me.txtID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtID.PlaceholderText = "ENTER ID"
        Me.txtID.SelectedText = ""
        Me.txtID.ShadowDecoration.Parent = Me.txtID
        Me.txtID.Size = New System.Drawing.Size(358, 34)
        Me.txtID.TabIndex = 6
        '
        'txtReciept
        '
        Me.txtReciept.AutoRoundedCorners = True
        Me.txtReciept.BackColor = System.Drawing.Color.Transparent
        Me.txtReciept.BorderRadius = 17
        Me.txtReciept.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtReciept.DefaultText = ""
        Me.txtReciept.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtReciept.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtReciept.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtReciept.DisabledState.Parent = Me.txtReciept
        Me.txtReciept.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtReciept.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtReciept.FocusedState.Parent = Me.txtReciept
        Me.txtReciept.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.txtReciept.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtReciept.HoverState.Parent = Me.txtReciept
        Me.txtReciept.Location = New System.Drawing.Point(153, 303)
        Me.txtReciept.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtReciept.Name = "txtReciept"
        Me.txtReciept.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtReciept.PlaceholderText = ""
        Me.txtReciept.SelectedText = ""
        Me.txtReciept.ShadowDecoration.Parent = Me.txtReciept
        Me.txtReciept.Size = New System.Drawing.Size(151, 36)
        Me.txtReciept.TabIndex = 2
        '
        'txtCourse
        '
        Me.txtCourse.AutoRoundedCorners = True
        Me.txtCourse.BackColor = System.Drawing.Color.Transparent
        Me.txtCourse.BorderRadius = 17
        Me.txtCourse.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCourse.DefaultText = ""
        Me.txtCourse.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtCourse.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtCourse.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtCourse.DisabledState.Parent = Me.txtCourse
        Me.txtCourse.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtCourse.Enabled = False
        Me.txtCourse.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCourse.FocusedState.Parent = Me.txtCourse
        Me.txtCourse.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.txtCourse.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCourse.HoverState.Parent = Me.txtCourse
        Me.txtCourse.Location = New System.Drawing.Point(162, 170)
        Me.txtCourse.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtCourse.Name = "txtCourse"
        Me.txtCourse.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCourse.PlaceholderText = ""
        Me.txtCourse.SelectedText = ""
        Me.txtCourse.ShadowDecoration.Parent = Me.txtCourse
        Me.txtCourse.Size = New System.Drawing.Size(356, 36)
        Me.txtCourse.TabIndex = 1
        '
        'txtFullName
        '
        Me.txtFullName.AutoRoundedCorners = True
        Me.txtFullName.BackColor = System.Drawing.Color.Transparent
        Me.txtFullName.BorderRadius = 16
        Me.txtFullName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFullName.DefaultText = ""
        Me.txtFullName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtFullName.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtFullName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtFullName.DisabledState.Parent = Me.txtFullName
        Me.txtFullName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtFullName.Enabled = False
        Me.txtFullName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFullName.FocusedState.Parent = Me.txtFullName
        Me.txtFullName.Font = New System.Drawing.Font("Century Schoolbook", 14.25!)
        Me.txtFullName.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFullName.HoverState.Parent = Me.txtFullName
        Me.txtFullName.Location = New System.Drawing.Point(162, 113)
        Me.txtFullName.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtFullName.PlaceholderText = ""
        Me.txtFullName.SelectedText = ""
        Me.txtFullName.ShadowDecoration.Parent = Me.txtFullName
        Me.txtFullName.Size = New System.Drawing.Size(356, 35)
        Me.txtFullName.TabIndex = 0
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'frmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(674, 505)
        Me.Controls.Add(Me.Guna2CustomGradientPanel1)
        Me.Name = "frmPayment"
        Me.Text = "Make Payment"
        Me.Guna2CustomGradientPanel1.ResumeLayout(False)
        Me.Guna2CustomGradientPanel1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents btnSearch As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtReciept As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtCourse As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtFullName As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents btnPayment As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents dtDate As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txtPaidTo As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txtAmountPaid As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
