﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Guna2GradientButton3 = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.cmbCourse = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2GradientButton2 = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox6 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtID = New Guna.UI2.WinForms.Guna2TextBox()
        Me.cmbGender = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtLn = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtFn = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GradientButton1 = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2GradientButton4 = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2GradientPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2GradientButton4)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2GradientButton3)
        Me.Guna2GradientPanel1.Controls.Add(Me.cmbCourse)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2GradientButton2)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2TextBox6)
        Me.Guna2GradientPanel1.Controls.Add(Me.txtID)
        Me.Guna2GradientPanel1.Controls.Add(Me.cmbGender)
        Me.Guna2GradientPanel1.Controls.Add(Me.txtLn)
        Me.Guna2GradientPanel1.Controls.Add(Me.txtFn)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2GradientButton1)
        Me.Guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.Black
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(1010, 495)
        Me.Guna2GradientPanel1.TabIndex = 0
        '
        'Guna2GradientButton3
        '
        Me.Guna2GradientButton3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2GradientButton3.AutoRoundedCorners = True
        Me.Guna2GradientButton3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2GradientButton3.BorderRadius = 21
        Me.Guna2GradientButton3.CheckedState.Parent = Me.Guna2GradientButton3
        Me.Guna2GradientButton3.CustomImages.Parent = Me.Guna2GradientButton3
        Me.Guna2GradientButton3.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GradientButton3.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientButton3.HoverState.Parent = Me.Guna2GradientButton3
        Me.Guna2GradientButton3.Location = New System.Drawing.Point(799, 3)
        Me.Guna2GradientButton3.Name = "Guna2GradientButton3"
        Me.Guna2GradientButton3.ShadowDecoration.Parent = Me.Guna2GradientButton3
        Me.Guna2GradientButton3.Size = New System.Drawing.Size(199, 45)
        Me.Guna2GradientButton3.TabIndex = 10
        Me.Guna2GradientButton3.Text = "Make Payment"
        '
        'cmbCourse
        '
        Me.cmbCourse.AutoRoundedCorners = True
        Me.cmbCourse.BackColor = System.Drawing.Color.Transparent
        Me.cmbCourse.BorderRadius = 17
        Me.cmbCourse.CustomizableEdges.TopRight = False
        Me.cmbCourse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmbCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCourse.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.cmbCourse.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmbCourse.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmbCourse.FocusedState.Parent = Me.cmbCourse
        Me.cmbCourse.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCourse.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmbCourse.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.cmbCourse.HoverState.Parent = Me.cmbCourse
        Me.cmbCourse.ItemHeight = 30
        Me.cmbCourse.ItemsAppearance.BackColor = System.Drawing.Color.Black
        Me.cmbCourse.ItemsAppearance.ForeColor = System.Drawing.Color.White
        Me.cmbCourse.ItemsAppearance.Parent = Me.cmbCourse
        Me.cmbCourse.Location = New System.Drawing.Point(46, 304)
        Me.cmbCourse.Name = "cmbCourse"
        Me.cmbCourse.ShadowDecoration.Parent = Me.cmbCourse
        Me.cmbCourse.Size = New System.Drawing.Size(308, 36)
        Me.cmbCourse.TabIndex = 9
        '
        'Guna2GradientButton2
        '
        Me.Guna2GradientButton2.AutoRoundedCorners = True
        Me.Guna2GradientButton2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2GradientButton2.BorderRadius = 21
        Me.Guna2GradientButton2.CheckedState.Parent = Me.Guna2GradientButton2
        Me.Guna2GradientButton2.CustomImages.Parent = Me.Guna2GradientButton2
        Me.Guna2GradientButton2.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.Guna2GradientButton2.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientButton2.HoverState.Parent = Me.Guna2GradientButton2
        Me.Guna2GradientButton2.Location = New System.Drawing.Point(46, 438)
        Me.Guna2GradientButton2.Name = "Guna2GradientButton2"
        Me.Guna2GradientButton2.ShadowDecoration.Parent = Me.Guna2GradientButton2
        Me.Guna2GradientButton2.Size = New System.Drawing.Size(130, 45)
        Me.Guna2GradientButton2.TabIndex = 8
        Me.Guna2GradientButton2.Text = "Clear"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Cornsilk
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(111, 12)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(167, 34)
        Me.Guna2HtmlLabel1.TabIndex = 7
        Me.Guna2HtmlLabel1.Text = "New Student"
        '
        'Guna2TextBox6
        '
        Me.Guna2TextBox6.AutoRoundedCorners = True
        Me.Guna2TextBox6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2TextBox6.BorderRadius = 17
        Me.Guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox6.DefaultText = ""
        Me.Guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox6.DisabledState.Parent = Me.Guna2TextBox6
        Me.Guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox6.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.Guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox6.FocusedState.Parent = Me.Guna2TextBox6
        Me.Guna2TextBox6.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.Guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox6.HoverState.Parent = Me.Guna2TextBox6
        Me.Guna2TextBox6.Location = New System.Drawing.Point(46, 368)
        Me.Guna2TextBox6.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Guna2TextBox6.Name = "Guna2TextBox6"
        Me.Guna2TextBox6.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox6.PlaceholderText = "Date Of Birth"
        Me.Guna2TextBox6.SelectedText = ""
        Me.Guna2TextBox6.ShadowDecoration.Parent = Me.Guna2TextBox6
        Me.Guna2TextBox6.Size = New System.Drawing.Size(308, 37)
        Me.Guna2TextBox6.TabIndex = 6
        '
        'txtID
        '
        Me.txtID.AutoRoundedCorners = True
        Me.txtID.BackColor = System.Drawing.Color.Transparent
        Me.txtID.BorderRadius = 17
        Me.txtID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtID.DefaultText = ""
        Me.txtID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtID.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtID.DisabledState.Parent = Me.txtID
        Me.txtID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtID.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.txtID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtID.FocusedState.Parent = Me.txtID
        Me.txtID.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.txtID.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtID.HoverState.Parent = Me.txtID
        Me.txtID.Location = New System.Drawing.Point(46, 65)
        Me.txtID.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtID.Name = "txtID"
        Me.txtID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtID.PlaceholderText = "Enter Your ID"
        Me.txtID.SelectedText = ""
        Me.txtID.ShadowDecoration.Parent = Me.txtID
        Me.txtID.Size = New System.Drawing.Size(308, 37)
        Me.txtID.TabIndex = 4
        '
        'cmbGender
        '
        Me.cmbGender.AutoRoundedCorners = True
        Me.cmbGender.BackColor = System.Drawing.Color.Transparent
        Me.cmbGender.BorderRadius = 17
        Me.cmbGender.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.cmbGender.DefaultText = ""
        Me.cmbGender.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.cmbGender.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.cmbGender.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.cmbGender.DisabledState.Parent = Me.cmbGender
        Me.cmbGender.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.cmbGender.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.cmbGender.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmbGender.FocusedState.Parent = Me.cmbGender
        Me.cmbGender.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.cmbGender.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.cmbGender.HoverState.Parent = Me.cmbGender
        Me.cmbGender.Location = New System.Drawing.Point(46, 247)
        Me.cmbGender.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.cmbGender.PlaceholderText = "Gender"
        Me.cmbGender.SelectedText = ""
        Me.cmbGender.ShadowDecoration.Parent = Me.cmbGender
        Me.cmbGender.Size = New System.Drawing.Size(308, 37)
        Me.cmbGender.TabIndex = 3
        '
        'txtLn
        '
        Me.txtLn.AutoRoundedCorners = True
        Me.txtLn.BackColor = System.Drawing.Color.Transparent
        Me.txtLn.BorderRadius = 17
        Me.txtLn.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLn.DefaultText = ""
        Me.txtLn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtLn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtLn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLn.DisabledState.Parent = Me.txtLn
        Me.txtLn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLn.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.txtLn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLn.FocusedState.Parent = Me.txtLn
        Me.txtLn.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.txtLn.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLn.HoverState.Parent = Me.txtLn
        Me.txtLn.Location = New System.Drawing.Point(46, 188)
        Me.txtLn.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtLn.Name = "txtLn"
        Me.txtLn.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtLn.PlaceholderText = "Last Name"
        Me.txtLn.SelectedText = ""
        Me.txtLn.ShadowDecoration.Parent = Me.txtLn
        Me.txtLn.Size = New System.Drawing.Size(308, 37)
        Me.txtLn.TabIndex = 2
        '
        'txtFn
        '
        Me.txtFn.AutoRoundedCorners = True
        Me.txtFn.BackColor = System.Drawing.Color.Transparent
        Me.txtFn.BorderRadius = 17
        Me.txtFn.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFn.DefaultText = ""
        Me.txtFn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtFn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtFn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtFn.DisabledState.Parent = Me.txtFn
        Me.txtFn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtFn.FillColor = System.Drawing.SystemColors.WindowFrame
        Me.txtFn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFn.FocusedState.Parent = Me.txtFn
        Me.txtFn.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.txtFn.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFn.HoverState.Parent = Me.txtFn
        Me.txtFn.Location = New System.Drawing.Point(46, 128)
        Me.txtFn.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.txtFn.Name = "txtFn"
        Me.txtFn.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtFn.PlaceholderText = "First Name"
        Me.txtFn.SelectedText = ""
        Me.txtFn.ShadowDecoration.Parent = Me.txtFn
        Me.txtFn.Size = New System.Drawing.Size(308, 37)
        Me.txtFn.TabIndex = 1
        '
        'Guna2GradientButton1
        '
        Me.Guna2GradientButton1.AutoRoundedCorners = True
        Me.Guna2GradientButton1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2GradientButton1.BorderRadius = 21
        Me.Guna2GradientButton1.CheckedState.Parent = Me.Guna2GradientButton1
        Me.Guna2GradientButton1.CustomImages.Parent = Me.Guna2GradientButton1
        Me.Guna2GradientButton1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GradientButton1.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientButton1.HoverState.Parent = Me.Guna2GradientButton1
        Me.Guna2GradientButton1.Location = New System.Drawing.Point(198, 438)
        Me.Guna2GradientButton1.Name = "Guna2GradientButton1"
        Me.Guna2GradientButton1.ShadowDecoration.Parent = Me.Guna2GradientButton1
        Me.Guna2GradientButton1.Size = New System.Drawing.Size(139, 45)
        Me.Guna2GradientButton1.TabIndex = 0
        Me.Guna2GradientButton1.Text = "Save"
        '
        'Guna2GradientButton4
        '
        Me.Guna2GradientButton4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2GradientButton4.AutoRoundedCorners = True
        Me.Guna2GradientButton4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2GradientButton4.BorderRadius = 21
        Me.Guna2GradientButton4.CheckedState.Parent = Me.Guna2GradientButton4
        Me.Guna2GradientButton4.CustomImages.Parent = Me.Guna2GradientButton4
        Me.Guna2GradientButton4.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GradientButton4.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientButton4.HoverState.Parent = Me.Guna2GradientButton4
        Me.Guna2GradientButton4.Location = New System.Drawing.Point(573, 3)
        Me.Guna2GradientButton4.Name = "Guna2GradientButton4"
        Me.Guna2GradientButton4.ShadowDecoration.Parent = Me.Guna2GradientButton4
        Me.Guna2GradientButton4.Size = New System.Drawing.Size(199, 45)
        Me.Guna2GradientButton4.TabIndex = 11
        Me.Guna2GradientButton4.Text = "View Balance"
        '
        'frmProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1010, 495)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.Name = "frmProfile"
        Me.Text = "New Student"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox6 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtID As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents cmbGender As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtLn As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtFn As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GradientButton1 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton2 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents cmbCourse As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2GradientButton3 As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2GradientButton4 As Guna.UI2.WinForms.Guna2GradientButton
End Class
