﻿Imports MySql.Data.MySqlClient

Public Class frmViewBalance
    Private Sub frmViewBalance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            'connect to db when the form load
            Dim con As New dbConnection
            con.connection.Open()
            con.query = "SELECT S.LastName, S.FirstName, L.Amount, S.CourseName from student S Join studentcourse C On S.ID=C.ID Join collegecourse L On L.Courses = S.CourseName"
            con.cm = New MySqlCommand(con.query, con.connection)
            con.dr = con.cm.ExecuteReader

            'clear the listview if their is previous items
            ListView1.Items.Clear()

            'create a listview variable
            Dim list As ListViewItem

            'loop through all the student and display in the listview itemss
            While con.dr.Read = True
                list = New ListViewItem(con.dr("LastName").ToString & " " & con.dr("FirstName").ToString)
                list.SubItems.Add(con.dr("CourseName"))
                list.SubItems.Add(con.dr("Amount"))
                ListView1.Items.Add(list)
            End While

            'close the connection
            con.connection.Close()
            con.cm.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            'connect to db when the form load
            Dim con As New dbConnection
            con.connection.Open()
            con.query = "SELECT S.LastName, S.FirstName, L.Amount, S.CourseName from student S Join studentcourse C On S.ID=C.ID Join collegecourse L On L.Courses = S.CourseName Where S.ID='" & Trim(txtID.Text) & "'"
            con.cm = New MySqlCommand(con.query, con.connection)
            con.dr = con.cm.ExecuteReader

            'clear the listview if their is previous items
            ListView1.Items.Clear()

            'create a listview variable
            Dim list As ListViewItem

            'loop through all the student and display in the listview itemss
            While con.dr.Read = True
                list = New ListViewItem(con.dr("LastName").ToString & " " & con.dr("FirstName").ToString)
                list.SubItems.Add(con.dr("CourseName"))
                list.SubItems.Add(con.dr("Amount"))
                ListView1.Items.Add(list)
                list.BackColor = Color.Green
            End While

            'close the connection
            con.connection.Close()
            con.cm.Dispose()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class