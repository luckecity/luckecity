﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btn_view.Click
        'calling the form to view all record in the database
        frm_view.Show()

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_modify.Click
        'calling the form for modifiying products
        frm_modify.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_add.Click
        'calling the form window for adding new product
        frm_add.Show()
        Me.Hide()


    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'closing the form if the person cannot login or after login details is taken
        Dim yes As Integer = MsgBox("Are you sure you want to close?", MsgBoxStyle.YesNo, "Comfirm")

        ' the 6 means yes the user want to close the form, this is by default how vb use to decide which button is pressed
        ' the 7 means NO the user doesn't want to close the form
        If yes = 6 Then
            Me.Close()
        Else
            yes = 7
        End If

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btn_login.Click

        'declaring the mysql variable to coneect and manipulate data

        Dim con As New MySqlConnection("server=localhost; user id=root; password=; database=stock")

        Dim dr As MySqlDataReader
        Try

            con.Open()

            Dim query As String = "SELECT Username, Password FROM login"
            Dim cm As New MySqlCommand(query, con)
            dr = cm.ExecuteReader
            While dr.Read = True

                Dim username As String = dr("Username")
                Dim password As String = dr("Password")
                'using if statement to validate the input and allow for login or show and error message
                If txt_username.Text = username And txt_password.Text = password Then
                    'setting all the button to allow the user to navigate when the 
                    'login details provided by the user is correct or matches the 
                    'system requirement
                    MessageBox.Show("YOU HAVE SUCCESSFULLY LOGIN IN")
                    btn_add.Enabled = True
                    btn_cost.Enabled = True
                    btn_delete.Enabled = True
                    btn_modify.Enabled = True
                    btn_report.Enabled = True
                    btn_search.Enabled = True
                    btn_view.Enabled = True

                    txt_password.Clear()
                    txt_username.Clear()
                    txt_username.Visible = False
                    txt_password.Visible = False
                    btn_login.Visible = False

                Else
                    login_error.Visible = True
                    txt_password.Clear()
                    txt_username.Clear()
                End If

            End While
            dr.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click

        frmDelete.Show()
        Me.Hide()

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        MessageBox.Show("please find out the features of a stock control system before you put unreasonable features")
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click

        MessageBox.Show("this are the features 1 Ability to use multiple currencies" & vbCrLf & "2 Ability to cover multiple warehouses" & vbCrLf &
                        "Can adapt to your business as it grows" & vbCrLf & "Serial/Batch tracking" & vbCrLf & "Support multiple users at once")

    End Sub
End Class
