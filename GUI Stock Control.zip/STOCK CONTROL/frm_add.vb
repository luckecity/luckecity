﻿Imports MySql.Data.MySqlClient
Public Class frm_add
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'calling the menu form and hiding the add product form
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader


        Try
            conn.Open()
            Dim query As String = "INSERT INTO product(Product_code,Product_Name,Product_Color,Quantity,MinOrderLevel) VALUES ('" & txtProductCode.Text.Trim & "', '" & txtProductName.Text & "', '" & cmbColor.Text & "', '" & txtQuantity.Text & "', '" & txtMinOrder.Text & "')"
            Dim cm As New MySqlCommand(query, conn)
            dr = cm.ExecuteReader


            Dim checking As Integer

            checking = cm.ExecuteNonQuery

            If checking > 0 Then
                lblsaved.Visible = True
                txtMinOrder.Clear()
                txtProductCode.Clear()
                txtProductName.Clear()
                txtQuantity.Clear()
                cmbColor.Text = String.Empty
                Panel1.BackColor = Color.Green
            Else
                lblsaved.Text = "UNABLE TO SAVE DATA"
                lblsaved.ForeColor = Color.Red
                lblsaved.Visible = True
            End If

            dr.Close()
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)



        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'clearing the textbox and setting the focus
        txtProductName.Clear()
        txtMinOrder.Clear()
        txtProductCode.Clear()
        txtQuantity.Clear()
        cmbColor.Text = String.Empty

        'setting the focus to product name
        txtProductName.Focus()

    End Sub
End Class