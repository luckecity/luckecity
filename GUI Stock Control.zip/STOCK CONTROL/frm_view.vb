﻿Imports MySql.Data.MySqlClient
Public Class frm_view

    'function for displaying all the products in the database
    Private Sub ViewAll()
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader

        Try
            conn.Open()
            Dim query As String = "SELECT * FROM product"
            Dim cm As New MySqlCommand(query, conn)
            dr = cm.ExecuteReader

            ListView1.Items.Clear()

            Dim list As ListViewItem
            While dr.Read = True
                list = New ListViewItem(dr("Product_Name").ToString)
                list.SubItems.Add(dr("Product_code"))
                list.SubItems.Add(dr("Quantity"))
                list.SubItems.Add(dr("Product_Color"))
                list.SubItems.Add(dr("MinOrderLevel"))
                ListView1.Items.Add(list)
            End While

            dr.Dispose()
            conn.Close()

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        Finally
            conn.Close()

        End Try
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub frm_view_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'calling the function we created to display all the record stored in the database 
        'When the form load
        ViewAll()
    End Sub
End Class