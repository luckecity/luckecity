﻿Imports MySql.Data.MySqlClient

Public Class frmDelete
    'function for displaying all the products in the database
    Private Sub View()
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader

        Try
            conn.Open()
            Dim query As String = "SELECT Product_Name, Product_code FROM product"
            Dim cm As New MySqlCommand(query, conn)
            dr = cm.ExecuteReader

            ListView1.Items.Clear()

            Dim list As ListViewItem
            While dr.Read = True
                list = New ListViewItem(dr("Product_Name").ToString)
                list.SubItems.Add(dr("Product_code"))
                ' list.SubItems.Add(dr("Quantity"))
                'list.SubItems.Add(dr("Product_Color"))
                'list.SubItems.Add(dr("MinOrderLevel"))
                ListView1.Items.Add(list)
            End While

            dr.Dispose()
            conn.Close()

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        Finally
            conn.Close()

        End Try
    End Sub

    'connecting to the database
    Private Sub DeleteProduct()
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader

        Try

            conn.Open() 'opening the connection to the product database

            Dim query As String = "DELETE FROM Product Where Product_code='" & txtDelete.Text & "'" ' our query for manipulating the database
            Dim cm As New MySqlCommand(query, conn) ' passing the connection and the mysql query
            dr = cm.ExecuteReader 'this is for executing the command and for reading


            MsgBox("Deleted Successfully", MsgBoxStyle.OkOnly, "Deleting")
                txtDelete.Clear()
                txtSproductCode.Clear()
                txtSproductColor.Clear()
                txtSproductMin.Clear()
                txtSproductName.Clear()
                txtSproductQuantity.Clear()

            cm.Dispose()
        Catch ex As Exception

            'if the product code is not in the database everything get erased
            txtDelete.Clear()
            txtSproductCode.Clear()
            txtSproductColor.Clear()
            txtSproductMin.Clear()
            txtSproductName.Clear()
            txtSproductQuantity.Clear()


            MsgBox("Product with Specified Code does not exist", MsgBoxStyle.OkOnly, "Unable to Delete")


        End Try
        conn.Close()
    End Sub
    Private Sub txtSproductName_TextChanged(sender As Object, e As EventArgs) Handles txtSproductName.TextChanged

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader

        Try

            conn.Open() 'opening the connection to the product database

            Dim query As String = "SELECT * FROM Product Where Product_code='" & txtDelete.Text & "'" ' our query for manipulating the database
            Dim cm As New MySqlCommand(query, conn) ' passing the connection and the mysql query
            dr = cm.ExecuteReader 'this is for executing the command and for reading

            If dr.Read Then

                'taking all the information and storing them on the textbox based on what the user searched for
                txtSproductCode.Text = dr("Product_code")
                txtSproductColor.Text = dr("Product_Color")
                txtSproductMin.Text = dr("MinOrderLevel")
                txtSproductName.Text = dr("Product_Name")
                txtSproductQuantity.Text = dr("Quantity")

            Else


                txtDelete.Clear()
                txtSproductCode.Clear()
                txtSproductColor.Clear()
                txtSproductMin.Clear()
                txtSproductName.Clear()
                txtSproductQuantity.Clear()

                MsgBox("Product with Specified Code does not exist", MsgBoxStyle.OkOnly, "Invalid Product Code")


            End If

            cm.Dispose()
        Catch ex As Exception
            'displaying the appropriate message to the user regarding the connection to the database
            MessageBox.Show(ex.Message)

        End Try
        conn.Close()
    End Sub

    Private Sub frmDelete_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        View()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtDelete.Clear()
        txtSproductCode.Clear()
        txtSproductColor.Clear()
        txtSproductMin.Clear()
        txtSproductName.Clear()
        txtSproductQuantity.Clear()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'this function is for displaying a specific products to delete
        DeleteProduct()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        View()
    End Sub
End Class