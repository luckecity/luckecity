﻿Imports MySql.Data.MySqlClient

Public Class frm_modify
    'connecting to the database
    Private Sub SearchProduct()
        Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=stock")
        Dim dr As MySqlDataReader

        Try

            conn.Open() 'opening the connection to the product database

            Dim query As String = "SELECT * FROM Product Where Product_code='" & txtSearchBox.Text & "'" ' our query for manipulating the database
            Dim cm As New MySqlCommand(query, conn) ' passing the connection and the mysql query
            dr = cm.ExecuteReader 'this is for executing the command and for reading

            If dr.Read Then

                'taking all the information and storing them on the textbox based on what the user searched for
                txtSproductCode.Text = dr("Product_code")
                txtSproductColor.Text = dr("Product_Color")
                txtSproductMin.Text = dr("MinOrderLevel")
                txtSproductName.Text = dr("Product_Name")
                txtSproductQuantity.Text = dr("Quantity")

                'manipulating the form itself
                Label14.ForeColor = Color.Teal
                modifyGroup.Enabled = True
            Else
                'if the product code is not in the database everything goes back to normal
                modifyGroup.Enabled = False
                GroupBox3.Enabled = False

                txtSearchBox.Clear()
                txtSproductCode.Clear()
                txtSproductColor.Clear()
                txtSproductMin.Clear()
                txtSproductName.Clear()
                txtSproductQuantity.Clear()

                MsgBox("Product with Specified Code does not exist", MsgBoxStyle.OkOnly, "Invalid Product Code")


            End If

            cm.Dispose()
        Catch ex As Exception
            'displaying the appropriate message to the user regarding the connection to the database
            MessageBox.Show(ex.Message)

        End Try
        conn.Close()
    End Sub


    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles modifyGroup.Enter

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'hiding the closin the current form and displaying the main menu

        Dim yes As Integer = MsgBox("Your Data will not be saved? Are you sure you want to close", MsgBoxStyle.YesNo, "Exit")
        ' the 6 means yes the user want to close the form, this is by default how vb use to decide which button is pressed
        ' the 7 means NO the user doesn't want to close the form
        If yes = 6 Then
            Me.Close()
            Form1.Show()
        Else
            yes = 7

        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SearchProduct()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'clearing all the textboxes
        txtSearchBox.Clear()
        txtSproductCode.Clear()
        txtSproductColor.Clear()
        txtSproductMin.Clear()
        txtSproductName.Clear()
        txtSproductQuantity.Clear()
        txtSproductCode.Clear()
        txtSproductColor.Clear()
        txtSproductMin.Clear()
        txtSproductName.Clear()
        txtSproductQuantity.Clear()

        modifyGroup.Enabled = False
        GroupBox3.Enabled = False

    End Sub

    Private Sub GroupBox5_Enter(sender As Object, e As EventArgs) Handles GroupBox5.Enter

    End Sub
End Class