﻿Imports MySql.Data.MySqlClient

Module dbConnection
    'this is a connection function to connect to the database
    Function connect()


        Dim conn As New MySqlConnection("server=localhost; username=; password=; database=stock")

        Return conn
    End Function
    'this variable is used to open the connection which is why
    'the ccess specifier is declared as public
    Public conn As MySqlConnection = connect()
End Module
