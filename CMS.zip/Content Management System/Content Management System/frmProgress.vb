﻿Imports MySql.Data.MySqlClient
Public Class frmProgress


    'function to update the customer tracking system
    Public Sub updateItem()
        'Dim con As New DBconnection
        '' Str = "UPDATE user SET firstname='" & txtfname.Text.ToUpper & "',lastname='" & txtlname.Text.ToUpper & "'," &
        ''"WHERE iduser='" & lblid.Text & "
        'Try
        '    con.conn.Open()
        '    Dim trackUpdate As String = txtTrackBox.Text.ToString

        '    con.query = "UPDATE Registration SET Status = '" & lblstatus.Text & "' WHERE ItemCode = '" & trackUpdate & "'"
        '    con.cm = New MySqlCommand(con.query, con.conn)
        '    con.dr = con.cm.ExecuteReader

        '    Dim i As Integer = con.cm.ExecuteNonQuery
        '    'notifying the user if the item is saved or not
        '    If i > 0 Then
        '        MessageBox.Show("Updated successfully")

        '    Else
        '        MessageBox.Show("Something Went WRONG")

        '    End If

        '    'clossing the connection
        '    con.conn.Dispose()
        '    con.cm.Dispose()
        '    con.dr.Close()

        'Catch ex As Exception
        '    MessageBox.Show(ex.Message)
        'End Try
    End Sub




    'function to search and display the march code
    Public Sub CodeTracking()
        'declaring the variables to connect to database
        'Dim con As New DBconnection



        'Try
        '    'connection opening
        '    con.conn.Open()
        '    con.query ="SELECT * FROM Registration WHERE ItemCode= '" & txtTrackBox.Text & "'"
        '    con.cm = New MySqlCommand(con.query, con.conn)
        '    con.dr = con.cm.ExecuteReader

        '    ListView1.Items.Clear()

        '    Dim list As ListViewItem
        '    While con.dr.Read = True

        '        'using if and else statement to display the right message to the user
        '        Dim code As String = con.dr("ItemCode")
        '        If code = txtTrackBox.Text Then
        '            list = New ListViewItem(con.dr("CustomerName").ToString)
        '            list.SubItems.Add(con.dr("ItemName"))
        '            list.SubItems.Add(con.dr("Phone"))
        '            list.SubItems.Add(con.dr("ItemCode"))
        '            list.SubItems.Add(con.dr("Status"))
        '            list.SubItems.Add(con.dr("DateBrought"))
        '            ListView1.Items.Add(list)

        '            ' txtTrackBox.Clear()

        '            TrackBar1.Visible = True

        '        ElseIf code IsNot txtTrackBox.Text Then

        '            MessageBox.Show("There is no record associated with this item Code " & txtTrackBox.Text)

        '        End If

        '    End While


        '    con.conn.Dispose()

        'Catch ex As Exception
        '    MessageBox.Show(ex.Message)
        'End Try
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        'calling the codetracking function to search,
        'this is created above at the starting point
        CodeTracking()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        'closing the form
        Me.Close()

    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        'setting the scrolling for the searching on the frmProgress form
        TrackBar1.LargeChange = 40
        TrackBar1.Minimum = 40
        TrackBar1.Maximum = 100


        If TrackBar1.Value <= 40 Then
            lblstatus.Text = "Pending"

        ElseIf TrackBar1.Value <= 80 Then
            lblstatus.Text = "Almost Done"

        ElseIf TrackBar1.Value <= 100 Then
            lblstatus.Text = "Successfully done"


        End If

    End Sub

    Private Sub frmProgress_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        'this module is defined and declared on top, please refer for reference and changes
        updateItem()
    End Sub
End Class