﻿Imports MySql.Data.MySqlClient
Public Class DBconnection

    'connecting to database
    Public conn As New MySqlConnection("server=localhost; user id=root; password=; database=CMS")
    Public query As String = ""
    Public dr As MySqlDataReader
    Public cm As New MySqlCommand()

End Class
