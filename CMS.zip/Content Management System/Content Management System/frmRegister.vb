﻿Imports MySql.Data.MySqlClient
Public Class frmRegister
    'function for Customer registration
    Private Sub CustomerRegistration()
        'Dim conn As New MySqlConnection("server=localhost; user id=root; password=; database=CMS")
        'Dim dr As MySqlDataReader

        'Try
        '    conn.Open()



        '    Dim query As String = "INSERT INTO Registration(CustomerName, Phone, ItemName, ItemCode, DateBrought, Status) VALUES  ('" & txtName.Text & "', '" & txtPhone.Text & "', '" & txtItemName.Text & "', '" & txtCode.Text & "', '" & dtToday.Text & "', '" & lblPending.Text & "')"
        '    Dim cm As New MySqlCommand(query, conn)
        '    dr = cm.ExecuteReader

        '    MessageBox.Show("Data Successfully Saved", "Saving", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '    txtItemName.Clear()
        '    txtCode.Clear()
        '    txtName.Clear()
        '    txtPhone.Clear()
        '    lblCode.Visible = False
        '    Label7.Visible = False
        '    Button1.Enabled = False
        '    Button3.Enabled = True

        '    conn.Close()
        '    dr.Dispose()
        'Catch ex As Exception
        '    MessageBox.Show(ex.Message)

        'Finally
        '    conn.Close()

        'End Try
    End Sub
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtItemName.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtCode.Clear()
        txtItemName.Clear()
        txtName.Clear()
        txtPhone.Clear()
        lblCode.Text = ""
        Label7.Visible = False
        Button3.Enabled = True
        Button1.Enabled = False


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'closing the form for customer registration
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'calling the function to register new customers
        CustomerRegistration()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim Rand As Random = New Random
        Dim NameExtract As String = txtName.Text & "WebCast"


        Try
            Dim i As String = NameExtract.Substring(0, 2)
            Dim ItemName As String = "WC" & txtItemName.Text.Substring(3, 2)

            Dim phone As Integer = CInt(txtPhone.Text)
            txtCode.Text = ItemName & Rand.Next(3, 100) & i.ToString
            lblCode.Text = txtCode.Text
            Button3.Enabled = False
            Button1.Enabled = True
            Label7.Visible = True
            lblCode.Visible = True



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try




    End Sub
End Class
