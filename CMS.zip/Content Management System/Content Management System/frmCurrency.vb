﻿Public Class frmCurrency
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'closing the form
        Me.Close()

    End Sub

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click

        Try
            Dim dollar As Double
            'Dim rand As Double
            Dim tax As Double = 0.25
            Dim service As Double = 0.1
            Dim bank As Double = 0.055
            Dim ChargePerDollar As Double = 18.0
            Dim Total As Double
            'assigning the variable to convert what is entered on the textbox to double
            dollar = CDbl(txtDollar.Text)


            Total = tax + service + bank + dollar * ChargePerDollar

            txtRand.Text = Total.ToString()

            'rand = CDbl(txtRand.Text)




        Catch ex As Exception

            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clearing whatever the user entered on the textbox
        txtDollar.Clear()
        txtRand.Clear()
        'setting the focus
        txtDollar.Focus()

    End Sub
End Class
