﻿Public Class frmDashboard
    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub RegisterCustomerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterCustomerToolStripMenuItem.Click
        'calling the form for registering the new customer
        frmRegister.Show()

    End Sub

    Private Sub ToolStripButton2_Click_1(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        'closing the entire program
        Me.Close()

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        'calling the form for converting dollar to rand
        frmCurrency.Show()

    End Sub

    Private Sub TrackProgressToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TrackProgressToolStripMenuItem.Click
        'calling the progress form to search and perform an operation
        frmProgress.Show()
    End Sub
End Class