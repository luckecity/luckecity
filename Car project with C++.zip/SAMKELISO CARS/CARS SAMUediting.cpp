#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <iomanip>
 
using namespace std;

int x=0;
int main() {
    FILE *fp, *ft;
    char another, choice;
    char anothers[100];
    int totStudents=0;
    int totBIT=0,totIT=0,totBSM=0,totTVF=0, totCRM=0;
    int totMaleBIT=0,totFemaleBIT=0,totMaleIT=0, totFemaleIT=0,totMaleBSM=0,totFemaleBSM=0,totMaleTVF=0,totFemaleTVF=0,totMaleCRM=0, totFemaleCRM=0;
    string courseNameBIT,courseNameIT,courseNameBSM, courseNameTVF, courseNameCRM;
 
struct student {
        char student_id[50],first_name[50], last_name[50],gender[50];
        char course[100];
        int semester;
    };
 
    struct student s;
    char xstudent_id[50], xfirst_name[50], xlast_name[50],xgender[50];
    long int recsize;
 
    fp=fopen("users.txt","rb+");
 
    if (fp == NULL) {
        fp = fopen("users.txt","wb+");
 
        if (fp==NULL)
        {
             puts("Cannot open file");
             return 0;
        }
    }
 
 
 recsize = sizeof(s);
 
 while(1) {
     system("cls");
 	cout <<"\n \t\t==========================================="<<endl;
     cout << "\t\t==SAMUKELISO CAR REGISTRATION PRPGRAM  ==";
     cout <<"\n \t\t===========================================\n";
     cout << "\n \t\t\tCH00SE FROM THE OPTIONS BELOW\n ";
     cout << "\n \t\t\t 1. Add/Insert   Records";
     cout << "\n \t\t\t 2. View/Print  Records";
     cout << "\n \t\t\t 3. Modify/Update Records";
     cout << "\n \t\t\t 4. Delete/Remove Records";
     cout << "\n \t\t\t 5. Carss Report Records";
     cout << "\n \t\t\t 6. About Project & Members";
     cout << "\n \t\t\t 7. Exit/Close   Program";
     cout << "\n\n";
     cout << "\t  SELECT YOUR CHOICE NUMBER : ";
     fflush(stdin);
     choice = getche();
     switch(choice)
     {
      case '1' :
            fseek(fp,0,SEEK_END);
            another ='Y';
            while(another == 'Y' || another == 'y')
            {
                system("cls");
                cout << "Enter Car Chashis Number : ";
                cin >> s.student_id;
                totStudents=totStudents+1;
                cout << "Enter Car Make : ";
                cin >> s.first_name;
                cout << "Enter Car Colour : ";
                cin >> s.last_name;
                cout << "Enter\t"<<s.first_name<<"'s\t  Cars: SELECT Model of Vihicle from bellow  : \n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                cin >> s.course;
               cout<<"PLEASE VERIFY\t"<<s.first_name<<"\t"<<s.last_name<<"s'\t Model (re-Select the LETTER)\n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                another = getche();  
				if(another=='a'||another=='A')
                {
                cout<<"The model selected is (Truck)\n";
				totBIT=totBIT+1;
				courseNameBIT="Truck.";
				cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
                cin >> s.gender;
                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
                cout << "1. MANUAL\n";
                cout << "2. AUTOMATIC\n";
                choice = getche();
				 if(choice=='1')
				 {
				cout<<"\n";
				 cout<<s.first_name <<"\tMANUAL\t\n";
				 totMaleBIT=totMaleBIT+1;	
				 }
				 else if(choice=='2')
					{
					cout<<"\n";
				 	cout<<s.first_name <<"\tAUTOMATIC\t\n";
					 totFemaleBIT=totFemaleBIT+1; 
				 	}
				 	else
				 		{
				 		cout<<"\n";
				 		cout<<"Your verification fails  (select 1 or 2)\n";	
				 		}
				 
				
                }
               else
               
	               if(another=='b'||another=='B')
	                {
	                cout<<"The model selected is (Sedan)\n";
					totIT=totIT+1;
					courseNameIT="Sedan";
					cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
	                cin >> s.gender;
	                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
	                cout << "1. MANUAL\n";
	                cout << "2. AUTOMATIC\n";
	                choice = getche();
					 if(choice=='1')
					 {
					cout<<"\n";
					 cout<<s.first_name <<"\tManual\t\n";
					 totMaleIT=totMaleIT+1;	
					 }
					 else if(choice=='2')
						{
						cout<<"\n";
					 	cout<<s.first_name <<"\tAutomatic\t\n";
						 totFemaleIT=totFemaleIT+1; 
					 	}
					 	else
					 		{
					 		cout<<"\n";
					 		cout<<"Your verification fails  (select 1 or 2)\n";	
					 		}
				 
						
	                }
               		else
		               if(another=='c'||another=='C')
		                {
		                cout<<"The model selected is (Van)\n";
						totBSM=totBSM+1;
						courseNameBSM="Van";
						cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
		                cin >> s.gender;
		                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
		                cout << "1. MANUAL\n";
		                cout << "2. AUTOMATIC\n";
		                choice = getche();
						 if(choice=='1')
						 {
						 cout<<"\n";
						 cout<<s.first_name <<"\t\tMANUAL\t\n";
						 totMaleBSM=totMaleBSM+1;	
						 }
						 else if(choice=='2')
							{
							cout<<"\n";
						 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
							 totFemaleBSM=totFemaleBSM+1; 
						 	}
						 	else
						 		{
						 	    cout<<"\n";
						 		cout<<"Your verification fails  (select 1 or 2)\n";	
						 		}
				 	
		                }
		                else
		                	if(another=='d'||another=='D')
			                {
			                cout<<"The model selected is (Buss)\n";
							totTVF=totTVF+1;
							courseNameTVF="Buss";
							cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
			                cin >> s.gender;
			                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
			                cout << "1. MANUAL\n";
			                cout << "2. AUTOMATIC\n";
			                choice = getche();
							 if(choice=='1')
							 {
							 cout<<"\n";
							 cout<<s.first_name <<"\t\tMANUAL\t\n";
							 totMaleTVF=totMaleTVF+1;	
							 }
							 else if(choice=='2')
								{
								cout<<"\n";
							 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
								 totFemaleTVF=totFemaleTVF+1; 
							 	}
							 	else
							 		{
							 		cout<<"\n";
							 		cout<<"Your verification fails  (select 1 or 2)\n";	
							 		}
							 	
			                }	
               				else
	               				if(another=='e'||another=='E')
				                {
				                cout<<"The model selected is (Sports Car)\n";
								totCRM=totCRM+1;
								courseNameCRM="SportsCar";
								cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
				                cin >> s.gender;
				                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
				                cout << "1. MANUAL\n";
				                cout << "2. AUTOMATIC\n";
				                choice = getche();
								 if(choice=='1')
								 {
								 cout<<"\n";
								 cout<<s.first_name <<"\t\tMANUAL\t\n";
								 totMaleCRM=totMaleCRM+1;	
								 }
								 else if(choice=='2')
									{
									cout<<"\n";
								 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
									 totFemaleCRM=totFemaleCRM+1; 
								 	}
								 	else
								 		{
								 		cout<<"Your verification fails  (select 1 or 2)\n";	
								 		}
				 	
				                }	              				
                cout << "Enter Year Registered   : ";
                cin >> s.semester;
                fwrite(&s,recsize,1,fp);
                cout << "\n Add Another Vehicle Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;
   case '2':
            system("cls");
           rewind(fp);
           cout << "=== View the Records in the Database ===";
           cout << "\n";
		   cout<<" CarCashisNumber|CarMake|CarColour|Transmition|CarModel|Amount \n";
		   cout<<"-----------------------------------------------------"<<endl;
           while (fread(&s,recsize,1,fp) == 1){
           cout << "\n";
          
           cout <<"\n" << s.student_id << setw(10) << s.first_name << setw(10)  << s.last_name<<setw(10)<<s.gender << setw(10)<<s.course <<  setw(8)  << s.semester;
           }
           cout << "\n\n";
           system("pause");
           break;
 
   case '3' :
            system("cls");
          another = 'Y';
          while (another == 'Y'|| another == 'y')
          {
               cout << "\n Enter  Cashish Number to modify details : ";
              cin >> xstudent_id;
 
            rewind(fp);
            while (fread(&s,recsize,1,fp) == 1)
            {
                if (strcmp(s.student_id,xstudent_id) == 0)
                {   
				    system("cls");
                	cout<<"\n";
                	cout<<"Cashish Number"<<"\t"<< xstudent_id<<"\t is available!!!";


                 
                
                cout << "Enter Car Cashis Number : ";
                cin >> s.student_id;
                totStudents=totStudents+1;
                cout << "Enter Car Make : ";
                cin >> s.first_name;
                cout << "Enter Car Colour : ";
                cin >> s.last_name;
                cout << "Enter\t"<<s.first_name<<"'s\t CARS: SELECT Model of Vihicle from bellow  : \n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                cin >> s.course;
               cout<<"PLEASE VERIFY\t"<<s.first_name<<"\t"<<s.last_name<<"s'\t MODEL (re-Select the LETTER)\n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                another = getche();  
				if(another=='a'||another=='A')
                {
                cout<<"The model select is (Truck)\n";
				totBIT=totBIT+1;
				courseNameBIT="Truck";
				cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
                cin >> s.gender;
                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
                cout << "1. MANUAL\n";
                cout << "2. AUTOMATIC\n";
                choice = getche();
				 if(choice=='1')
				 {
				cout<<"\n";
				 cout<<s.first_name <<"\t MANUAL\t\n";
				 totMaleBIT=totMaleBIT+1;	
				 }
				 else if(choice=='2')
					{
					cout<<"\n";
				 	cout<<s.first_name <<"\t AUTOMATIC\t\n";
					 totFemaleBIT=totFemaleBIT+1; 
				 	}
				 	else
				 		{
				 		cout<<"\n";
				 		cout<<"Your verification fails  (select 1 or 2)\n";	
				 		}
				 
				
                }
               else
               
	               if(another=='b'||another=='B')
	                {
	                cout<<"The Model Selected is(Sedan)\n";
					totIT=totIT+1;
					courseNameIT="Sedan";
					cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
	                cin >> s.gender;
	                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
	                cout << "1. MANUAL\n";
	                cout << "2. AUTOMATIC\n";
	                choice = getche();
					 if(choice=='1')
					 {
					cout<<"\n";
					 cout<<s.first_name <<"\tMANUAL\t\n";
					 totMaleIT=totMaleIT+1;	
					 }
					 else if(choice=='2')
						{
						cout<<"\n";
					 	cout<<s.first_name <<"\tTRANSMITION\t\n";
						 totFemaleIT=totFemaleIT+1; 
					 	}
					 	else
					 		{
					 		cout<<"\n";
					 		cout<<"Your verification fails  (select 1 or 2)\n";	
					 		}
				 
						
	                }
               		else
		               if(another=='c'||another=='C')
		                {
		                cout<<"The Moedle Selected is (Van)\n";
						totBSM=totBSM+1;
						courseNameBSM="Van";
						cout << "Enter "<<s.first_name<<" "<<"TRANSMIIION : ";
		                cin >> s.gender;
		                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
		                cout << "1. MANUAL\n";
		                cout << "2. AUTOMATIC\n";
		                choice = getche();
						 if(choice=='1')
						 {
						 cout<<"\n";
						 cout<<s.first_name <<"\t\tMANUAL\t\n";
						 totMaleBSM=totMaleBSM+1;	
						 }
						 else if(choice=='2')
							{
							cout<<"\n";
						 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
							 totFemaleBSM=totFemaleBSM+1; 
						 	}
						 	else
						 		{
						 	    cout<<"\n";
						 		cout<<"Your verification fails  (select 1 or 2)\n";	
						 		}
				 	
		                }
		                else
		                	if(another=='d'||another=='D')
			                {
			                cout<<"The Model Selected is (Buss)\n";
							totTVF=totTVF+1;
							courseNameTVF="Buss";
							cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
			                cin >> s.gender;
			                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
			                cout << "1. MANUAL\n";
			                cout << "2. AUTOMATIC\n";
			                choice = getche();
							 if(choice=='1')
							 {
							 cout<<"\n";
							 cout<<s.first_name <<"\t\tMANUAL\t\n";
							 totMaleTVF=totMaleTVF+1;	
							 }
							 else if(choice=='2')
								{
								cout<<"\n";
							 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
								 totFemaleTVF=totFemaleTVF+1; 
							 	}
							 	else
							 		{
							 		cout<<"\n";
							 		cout<<"Your verification fails  (select 1 or 2)\n";	
							 		}
							 	
			                }	
               				else
	               				if(another=='e'||another=='E')
				                {
				                cout<<"The Model Selected is (Sports Car)\n";
								totCRM=totCRM+1;
								courseNameCRM="V.W";
								cout << "Enter "<<s.first_name<<" "<<"TRANSMITION : ";
				                cin >> s.gender;
				                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
				                cout << "1. MANUAL\n";
				                cout << "2. AUTOMATIC\n";
				                choice = getche();
								 if(choice=='1')
								 {
								 cout<<"\n";
								 cout<<s.first_name <<"\t\tMANUAL\t\n";
								 totMaleCRM=totMaleCRM+1;	
								 }
								 else if(choice=='2')
									{
									cout<<"\n";
								 	cout<<s.first_name <<"\t\tAUTOMATIC\t\n";
									 totFemaleCRM=totFemaleCRM+1; 
								 	}
								 	else
								 		{
								 		cout<<"Your verification fails  (select 1 or 2)\n";	
								 		}
				 	
				                }	              				
            
                cout << "Enter year evaluated   : ";
                cin >> s.semester;
                fseek(fp, - recsize, SEEK_CUR);
                fwrite(&s,recsize,1,fp);
                break;
                
                
                }
                else
            cout<<"Cashis Number does not exist. Please try again\n\n";
            system("cls");
            }
            cout<<" You are given another chance\n";
            cout << "\n Modify Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;
 
 
     case '4':
       system("cls");
           another = 'Y';
          while (another == 'Y'|| another == 'y')
          {
              cout << "\n Enter  Cashis Number to delete : ";
              cin >> xstudent_id;
 
 
              ft = fopen("temp.dat", "wb");
 
              rewind(fp);
              while (fread (&s, recsize,1,fp) == 1)
 
                 if (strcmp(s.student_id,xstudent_id) != 0)
                {
                    fwrite(&s,recsize,1,ft);
                }
                fclose(fp);
                fclose(ft);
                remove("users.txt");
                rename("temp.dat","users.txt");
 
                fp=fopen("users.txt","rb+");
 
                cout << "\n Delete Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
              }
 
              break;

			case '5': 
	            system("cls");
	            rewind(fp);
	            cout << "====COURSES REPORT AT LIMKOKWING UNIVERSITY OF CREATIVE TECHNOLOGY====\n";
	            cout<<"________________________________________________________________\n";
	            cout<<"CAR MODEL NAME";cout<<"       ";cout<<"TOTAL NUMBER OF CARS REGISTERED";cout<<"          "<<endl;
				cout << " \n";
				cout<<courseNameBIT;cout<<"    \t\t\t\t";cout<<totBIT;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<courseNameIT;cout<<"    \t\t\t\t";cout<<totIT;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<courseNameBSM;cout<<"    \t\t\t\t";cout<<totBSM;cout<<"        \n";
				cout<<"---------------------------------------------------------\n"; 
				cout<<courseNameTVF;cout<<"    \t\t\t\t";cout<<totTVF;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<courseNameCRM;cout<<"    \t\t\t\t";cout<<totCRM;cout<<"        \n";
				cout<<"=================================================================\n";  
	            cout << " \n\n\n";
	            
	            cout<<"CAR MODEL NAME";cout<<"\t\t";cout<<"NUMBER OF MANUAL CARS REGISTERED";cout<<"          "<<endl;
	            cout<<"________________________________________________________________\n";
	            cout<<courseNameBIT;cout<<"    \t\t\t\t";cout<<totMaleBIT;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameIT;cout<<"    \t\t\t\t";cout<<totMaleIT;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameBSM;cout<<"    \t\t\t\t";cout<<totMaleBSM;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameTVF;cout<<"    \t\t\t\t";cout<<totMaleTVF;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameCRM;cout<<"    \t\t\t\t";cout<<totMaleCRM;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout << "\n\n\n";
	            
	            cout<<"CAR MODEL NAME";cout<<" \t\t";cout<<"NUMBER OF AUTOMATIC CARS REGISTERED";cout<<"          "<<endl;
	            cout<<"________________________________________________________________\n";
	            cout<<courseNameBIT;cout<<"    \t\t\t\t";cout<<totFemaleBIT;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameIT;cout<<"    \t\t\t\t";cout<<totFemaleIT;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameBSM;cout<<"    \t\t\t\t";cout<<totFemaleBSM;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameTVF;cout<<"    \t\t\t\t";cout<<totFemaleTVF;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<courseNameCRM;cout<<"    \t\t\t\t";cout<<totFemaleCRM;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout << "\n\n\n";
	            
	            system("pause");
            break;
              
            case '6':
            system("cls");
            rewind(fp);
            cout << "====PROJECT DONE BY ====\n";
            cout << "1 ** SAMUKELISO\n";
           
            
            cout << "** ABOUT THE PROJECT \n";
            cout << "**-------------------------\n";
            cout << "** We are assigned to design and impliment student registration system in c++ language  \n";
            cout << "** The program must do the following;   \n";
            cout << "-- System must Register student details and be able to ADD, EDIT, DELETE.  \n";
            cout << "--The system must save the information into text file(Its saves to notepad named 'users.txt' and display the results in console  \n";
            cout << "-- User able to view all students. In each course shows enrollment and number of males and females per course  \n";
            cout << "-- And show the project summary and the group members that experience sleepless nights programming the system \n";
            cout << "\n\n";
            system("pause");
            break;
 
              case '7':
              fclose(fp);
              cout << "\n\n";
              cout << "\n\n";
              cout << "\tTHANK YOU FOR USING SAM CARS REGISTRATION SYSTEM\n\n";
              exit(0);
		}   
     }
 
 
system("pause");
return 0;
}
