#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <iomanip>
 
using namespace std;

int x=0;
int main() {
    FILE *fp, *ft;
    char another, choice;
    char anothers[100];
    int totCars=0;
    int totTruck=0,totSedan=0,totVan=0,totBuss=0, totSportsCar=0;
    int totManualTruck=0,totAutomaticTruck=0,totManualSedan=0, totAutomaticSedan=0,totManualVan=0,totAutomaticVan=0,totManualBuss=0,totAutomaticBuss=0,totManualSportsCar=0, totAutomaticSportsCar=0;
    string modelNameTruck,modelNameSedan,modelNameVan, modelNameBuss, modelNameSportsCar;
 
struct Car {
        char Car_id[50],Car_Make[50], Car_Colour[50],Transmition[50];
        char course[100];
        int yearRegistered;
    };
 
    struct Car s;
    char xCar_id[50], xCar_Make[50], xCar_Colour[50],xTransmition[50];
    long int recsize;
 
    fp=fopen("users.txt","rb+");
 
    if (fp == NULL) {
        fp = fopen("users.txt","wb+");
 
        if (fp==NULL)
        {
             puts("Cannot open file");
             return 0;
        }
    }
 
 
 recsize = sizeof(s);
 
 while(1) {
     system("cls");
 	cout <<"\n \t\t==========================================="<<endl;
     cout << "\t\t==SAMUKELISO CAR REGISTRATION PRPGRAM  ==";
     cout <<"\n \t\t===========================================\n";
     cout << "\n \t\t\tCH00SE FROM THE OPTIONS BELOW\n ";
     cout << "\n \t\t\t 1. Add/Insert   Records";
     cout << "\n \t\t\t 2. View/Print  Records";
     cout << "\n \t\t\t 3. Modify/Update Records";
     cout << "\n \t\t\t 4. Delete/Remove Records";
     cout << "\n \t\t\t 5. Carss Report Records";
     cout << "\n \t\t\t 6. About Project & Members";
     cout << "\n \t\t\t 7. Exit/Close   Program";
     cout << "\n\n";
     cout << "\t  SELECT YOUR CHOICE NUMBER : ";
     fflush(stdin);
     choice = getche();
     switch(choice)
     {
      case '1' :
            fseek(fp,0,SEEK_END);
            another ='Y';
            while(another == 'Y' || another == 'y')
            {
                system("cls");
                cout << "Enter Car Chashis Number : ";
                cin >> s.Car_id;
                totCars=totCars+1;
                cout << "Enter Car Make : ";
                cin >> s.Car_Make;
                cout << "Enter Car Colour : ";
                cin >> s.Car_Colour;
                cout << "Enter\t"<<s.Car_Make<<"'s\t  Cars: SELECT Model of Vihicle from bellow  : \n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                cin >> s.course;
               cout<<"PLEASE VERIFY\t"<<s.Car_Make<<"\t"<<s.Car_Colour<<"s'\t Model (re-Select the LETTER)\n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                another = getche();  
				if(another=='a'||another=='A')
                {
                cout<<"The model selected is (Truck)\n";
				totTruck=totTruck+1;
				modelNameTruck="Truck.";
				cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
                cin >> s.Transmition;
                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
                cout << "1. MANUAL\n";
                cout << "2. AUTOMATIC\n";
                choice = getche();
				 if(choice=='1')
				 {
				cout<<"\n";
				 cout<<s.Car_Make <<"\tMANUAL\t\n";
				 totManualTruck=totManualTruck+1;	
				 }
				 else if(choice=='2')
					{
					cout<<"\n";
				 	cout<<s.Car_Make <<"\tAUTOMATIC\t\n";
					 totAutomaticTruck=totAutomaticTruck+1; 
				 	}
				 	else
				 		{
				 		cout<<"\n";
				 		cout<<"Your verification fails  (select 1 or 2)\n";	
				 		}
				 
				
                }
               else
               
	               if(another=='b'||another=='B')
	                {
	                cout<<"The model selected is (Sedan)\n";
					totSedan=totSedan+1;
					modelNameSedan="Sedan";
					cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
	                cin >> s.Transmition;
	                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
	                cout << "1. MANUAL\n";
	                cout << "2. AUTOMATIC\n";
	                choice = getche();
					 if(choice=='1')
					 {
					cout<<"\n";
					 cout<<s.Car_Make <<"\tManual\t\n";
					 totManualSedan=totManualSedan+1;	
					 }
					 else if(choice=='2')
						{
						cout<<"\n";
					 	cout<<s.Car_Make <<"\tAutomatic\t\n";
						 totAutomaticSedan=totAutomaticSedan+1; 
					 	}
					 	else
					 		{
					 		cout<<"\n";
					 		cout<<"Your verification fails  (select 1 or 2)\n";	
					 		}
				 
						
	                }
               		else
		               if(another=='c'||another=='C')
		                {
		                cout<<"The model selected is (Van)\n";
						totVan=totVan+1;
						modelNameVan="Van";
						cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
		                cin >> s.Transmition;
		                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
		                cout << "1. MANUAL\n";
		                cout << "2. AUTOMATIC\n";
		                choice = getche();
						 if(choice=='1')
						 {
						 cout<<"\n";
						 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
						 totManualVan=totManualVan+1;	
						 }
						 else if(choice=='2')
							{
							cout<<"\n";
						 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
							 totAutomaticVan=totAutomaticVan+1; 
						 	}
						 	else
						 		{
						 	    cout<<"\n";
						 		cout<<"Your verification fails  (select 1 or 2)\n";	
						 		}
				 	
		                }
		                else
		                	if(another=='d'||another=='D')
			                {
			                cout<<"The model selected is (Buss)\n";
							totBuss=totBuss+1;
							modelNameBuss="Buss";
							cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
			                cin >> s.Transmition;
			                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
			                cout << "1. MANUAL\n";
			                cout << "2. AUTOMATIC\n";
			                choice = getche();
							 if(choice=='1')
							 {
							 cout<<"\n";
							 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
							 totManualBuss=totManualBuss+1;	
							 }
							 else if(choice=='2')
								{
								cout<<"\n";
							 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
								 totAutomaticBuss=totAutomaticBuss+1; 
							 	}
							 	else
							 		{
							 		cout<<"\n";
							 		cout<<"Your verification fails  (select 1 or 2)\n";	
							 		}
							 	
			                }	
               				else
	               				if(another=='e'||another=='E')
				                {
				                cout<<"The model selected is (Sports Car)\n";
								totSportsCar=totSportsCar+1;
								modelNameSportsCar="SportsCar";
								cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
				                cin >> s.Transmition;
				                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
				                cout << "1. MANUAL\n";
				                cout << "2. AUTOMATIC\n";
				                choice = getche();
								 if(choice=='1')
								 {
								 cout<<"\n";
								 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
								 totManualSportsCar=totManualSportsCar+1;	
								 }
								 else if(choice=='2')
									{
									cout<<"\n";
								 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
									 totAutomaticSportsCar=totAutomaticSportsCar+1; 
								 	}
								 	else
								 		{
								 		cout<<"Your verification fails  (select 1 or 2)\n";	
								 		}
				 	
				                }	              				
                cout << "Enter Year Registered   : ";
                cin >> s.yearRegistered;
                fwrite(&s,recsize,1,fp);
                cout << "\n Add Another Vehicle Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;
   case '2':
            system("cls");
           rewind(fp);
           cout << "=== View the Records in the Database ===";
           cout << "\n";
		   cout<<" CarCashisNumber|CarMake|CarColour|Transmition|CarModel|Amount \n";
		   cout<<"-----------------------------------------------------"<<endl;
           while (fread(&s,recsize,1,fp) == 1){
           cout << "\n";
          
           cout <<"\n" << s.Car_id << setw(10) << s.Car_Make << setw(10)  << s.Car_Colour<<setw(10)<<s.Transmition << setw(10)<<s.course <<  setw(8)  << s.yearRegistered;
           }
           cout << "\n\n";
           system("pause");
           break;
 
   case '3' :
            system("cls");
          another = 'Y';
          while (another == 'Y'|| another == 'y')
          {
               cout << "\n Enter  Cashish Number to modify details : ";
              cin >> xCar_id;
 
            rewind(fp);
            while (fread(&s,recsize,1,fp) == 1)
            {
                if (strcmp(s.Car_id,xCar_id) == 0)
                {   
				    system("cls");
                	cout<<"\n";
                	cout<<"Cashish Number"<<"\t"<< xCar_id<<"\t is available!!!";


                 
                
                cout << "Enter Car Cashis Number : ";
                cin >> s.Car_id;
                totCars=totCars+1;
                cout << "Enter Car Make : ";
                cin >> s.Car_Make;
                cout << "Enter Car Colour : ";
                cin >> s.Car_Colour;
                cout << "Enter\t"<<s.Car_Make<<"'s\t CARS: SELECT Model of Vihicle from bellow  : \n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                cin >> s.course;
               cout<<"PLEASE VERIFY\t"<<s.Car_Make<<"\t"<<s.Car_Colour<<"s'\t MODEL (re-Select the LETTER)\n";
                cout << "A. Truck ";
                cout << "B. Sedan ";
                cout << "C. Van ";
                cout << "D. Buss ";
                cout << "E. Sports Car \n";
                another = getche();  
				if(another=='a'||another=='A')
                {
                cout<<"The model select is (Truck)\n";
				totTruck=totTruck+1;
				modelNameTruck="Truck";
				cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
                cin >> s.Transmition;
                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
                cout << "1. MANUAL\n";
                cout << "2. AUTOMATIC\n";
                choice = getche();
				 if(choice=='1')
				 {
				cout<<"\n";
				 cout<<s.Car_Make <<"\t MANUAL\t\n";
				 totManualTruck=totManualTruck+1;	
				 }
				 else if(choice=='2')
					{
					cout<<"\n";
				 	cout<<s.Car_Make <<"\t AUTOMATIC\t\n";
					 totAutomaticTruck=totAutomaticTruck+1; 
				 	}
				 	else
				 		{
				 		cout<<"\n";
				 		cout<<"Your verification fails  (select 1 or 2)\n";	
				 		}
				 
				
                }
               else
               
	               if(another=='b'||another=='B')
	                {
	                cout<<"The Model Selected is(Sedan)\n";
					totSedan=totSedan+1;
					modelNameSedan="Sedan";
					cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
	                cin >> s.Transmition;
	                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
	                cout << "1. MANUAL\n";
	                cout << "2. AUTOMATIC\n";
	                choice = getche();
					 if(choice=='1')
					 {
					cout<<"\n";
					 cout<<s.Car_Make <<"\tMANUAL\t\n";
					 totManualSedan=totManualSedan+1;	
					 }
					 else if(choice=='2')
						{
						cout<<"\n";
					 	cout<<s.Car_Make <<"\tTRANSMITION\t\n";
						 totAutomaticSedan=totAutomaticSedan+1; 
					 	}
					 	else
					 		{
					 		cout<<"\n";
					 		cout<<"Your verification fails  (select 1 or 2)\n";	
					 		}
				 
						
	                }
               		else
		               if(another=='c'||another=='C')
		                {
		                cout<<"The Moedle Selected is (Van)\n";
						totVan=totVan+1;
						modelNameVan="Van";
						cout << "Enter "<<s.Car_Make<<" "<<"TRANSMIIION : ";
		                cin >> s.Transmition;
		                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
		                cout << "1. MANUAL\n";
		                cout << "2. AUTOMATIC\n";
		                choice = getche();
						 if(choice=='1')
						 {
						 cout<<"\n";
						 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
						 totManualVan=totManualVan+1;	
						 }
						 else if(choice=='2')
							{
							cout<<"\n";
						 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
							 totAutomaticVan=totAutomaticVan+1; 
						 	}
						 	else
						 		{
						 	    cout<<"\n";
						 		cout<<"Your verification fails  (select 1 or 2)\n";	
						 		}
				 	
		                }
		                else
		                	if(another=='d'||another=='D')
			                {
			                cout<<"The Model Selected is (Buss)\n";
							totBuss=totBuss+1;
							modelNameBuss="Buss";
							cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
			                cin >> s.Transmition;
			                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
			                cout << "1. MANUAL\n";
			                cout << "2. AUTOMATIC\n";
			                choice = getche();
							 if(choice=='1')
							 {
							 cout<<"\n";
							 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
							 totManualBuss=totManualBuss+1;	
							 }
							 else if(choice=='2')
								{
								cout<<"\n";
							 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
								 totAutomaticBuss=totAutomaticBuss+1; 
							 	}
							 	else
							 		{
							 		cout<<"\n";
							 		cout<<"Your verification fails  (select 1 or 2)\n";	
							 		}
							 	
			                }	
               				else
	               				if(another=='e'||another=='E')
				                {
				                cout<<"The Model Selected is (Sports Car)\n";
								totSportsCar=totSportsCar+1;
								modelNameSportsCar="V.W";
								cout << "Enter "<<s.Car_Make<<" "<<"TRANSMITION : ";
				                cin >> s.Transmition;
				                cout<<"PLEASE VERIFY TRANSMITION (Select 1 or 2)\n";
				                cout << "1. MANUAL\n";
				                cout << "2. AUTOMATIC\n";
				                choice = getche();
								 if(choice=='1')
								 {
								 cout<<"\n";
								 cout<<s.Car_Make <<"\t\tMANUAL\t\n";
								 totManualSportsCar=totManualSportsCar+1;	
								 }
								 else if(choice=='2')
									{
									cout<<"\n";
								 	cout<<s.Car_Make <<"\t\tAUTOMATIC\t\n";
									 totAutomaticSportsCar=totAutomaticSportsCar+1; 
								 	}
								 	else
								 		{
								 		cout<<"Your verification fails  (select 1 or 2)\n";	
								 		}
				 	
				                }	              				
            
                cout << "Enter year evaluated   : ";
                cin >> s.yearRegistered;
                fseek(fp, - recsize, SEEK_CUR);
                fwrite(&s,recsize,1,fp);
                break;
                
                
                }
                else
            cout<<"Cashis Number does not exist. Please try again\n\n";
            system("cls");
            }
            cout<<" You are given another chance\n";
            cout << "\n Modify Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
            }
            break;
 
 
     case '4':
       system("cls");
           another = 'Y';
          while (another == 'Y'|| another == 'y')
          {
              cout << "\n Enter  Cashis Number to delete : ";
              cin >> xCar_id;
 
 
              ft = fopen("temp.dat", "wb");
 
              rewind(fp);
              while (fread (&s, recsize,1,fp) == 1)
 
                 if (strcmp(s.Car_id,xCar_id) != 0)
                {
                    fwrite(&s,recsize,1,ft);
                }
                fclose(fp);
                fclose(ft);
                remove("users.txt");
                rename("temp.dat","users.txt");
 
                fp=fopen("users.txt","rb+");
 
                cout << "\n Delete Another Record (Y/N) ";
                fflush(stdin);
                another = getchar();
              }
 
              break;

			case '5': 
	            system("cls");
	            rewind(fp);
	            cout << "====COURSES REPORT AT LIMKOKWING UNIVERSITY OF CREATIVE TECHNOLOGY====\n";
	            cout<<"________________________________________________________________\n";
	            cout<<"CAR MODEL NAME";cout<<"       ";cout<<"TOTAL NUMBER OF CARS REGISTERED";cout<<"          "<<endl;
				cout << " \n";
				cout<<modelNameTruck;cout<<"    \t\t\t\t";cout<<totTruck;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<modelNameSedan;cout<<"    \t\t\t\t";cout<<totSedan;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<modelNameVan;cout<<"    \t\t\t\t";cout<<totVan;cout<<"        \n";
				cout<<"---------------------------------------------------------\n"; 
				cout<<modelNameBuss;cout<<"    \t\t\t\t";cout<<totBuss;cout<<"        \n";
				cout<<"---------------------------------------------------------\n";
				cout<<modelNameSportsCar;cout<<"    \t\t\t\t";cout<<totSportsCar;cout<<"        \n";
				cout<<"=================================================================\n";  
	            cout << " \n\n\n";
	            
	            cout<<"CAR MODEL NAME";cout<<"\t\t";cout<<"NUMBER OF MANUAL CARS REGISTERED";cout<<"          "<<endl;
	            cout<<"________________________________________________________________\n";
	            cout<<modelNameTruck;cout<<"    \t\t\t\t";cout<<totManualTruck;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameSedan;cout<<"    \t\t\t\t";cout<<totManualSedan;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameVan;cout<<"    \t\t\t\t";cout<<totManualVan;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameBuss;cout<<"    \t\t\t\t";cout<<totManualBuss;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameSportsCar;cout<<"    \t\t\t\t";cout<<totManualSportsCar;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout << "\n\n\n";
	            
	            cout<<"CAR MODEL NAME";cout<<" \t\t";cout<<"NUMBER OF AUTOMATIC CARS REGISTERED";cout<<"          "<<endl;
	            cout<<"________________________________________________________________\n";
	            cout<<modelNameTruck;cout<<"    \t\t\t\t";cout<<totAutomaticTruck;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameSedan;cout<<"    \t\t\t\t";cout<<totAutomaticSedan;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameVan;cout<<"    \t\t\t\t";cout<<totAutomaticVan;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameBuss;cout<<"    \t\t\t\t";cout<<totAutomaticBuss;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout<<modelNameSportsCar;cout<<"    \t\t\t\t";cout<<totAutomaticSportsCar;cout<<"        "<<endl;
	            cout<<"---------------------------------------------------------\n";
	            cout << "\n\n\n";
	            
	            system("pause");
            break;
              
            case '6':
            system("cls");
            rewind(fp);
            cout << "====PROJECT DONE BY ====\n";
            cout << "1 ** SAMUKELISO\n";
           
            
            cout << "** ABOUT THE PROJECT \n";
            cout << "**-------------------------\n";
            cout << "** We are assigned to design and impliment Car registration system in c++ language  \n";
            cout << "** The program must do the following;   \n";
            cout << "-- System must Register Car details and be able to ADD, EDIT, DELETE.  \n";
            cout << "--The system must save the information into text file(Its saves to notepad named 'users.txt' and display the results in console  \n";
            cout << "-- User able to view all Cars. In each course shows enrollment and number of males and females per course  \n";
            cout << "-- And show the project summary and the group members that experience sleepless nights programming the system \n";
            cout << "\n\n";
            system("pause");
            break;
 
              case '7':
              fclose(fp);
              cout << "\n\n";
              cout << "\n\n";
              cout << "\tTHANK YOU FOR USING SAM CARS REGISTRATION SYSTEM\n\n";
              exit(0);
		}   
     }
 
 
system("pause");
return 0;
}

